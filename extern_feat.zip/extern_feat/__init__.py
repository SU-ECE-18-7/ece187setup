'''
Interface to external keypoint / descriptor detectors

Downloaded compute_descriptors from:
    http://www.featurespace.org/

Downloaded hesaff from:
    https://github.com/perdoch/hesaff
'''
from __future__ import division, print_function
