./compute_descriptors_32bit.ln -i lena.png -hessian -sift
